# Comment

# Second comment


# Ask user for input
name = input("What's your name? ")

""" Random docstring """


# Print letters
for letter in name:
    print(letter)

# Print name
print(f"Hello, {name}")
