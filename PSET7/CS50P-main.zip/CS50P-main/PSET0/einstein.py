#gets input from user
get=int(input("m:"))
if get==1:
    num=90000000000000000
elif get==14:
    num=1260000000000000000
else:
    num=4500000000000000000

print("E:",num)
