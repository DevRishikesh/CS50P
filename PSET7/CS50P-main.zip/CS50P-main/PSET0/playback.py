str=str(input())
print(str.replace(" ","..."))
