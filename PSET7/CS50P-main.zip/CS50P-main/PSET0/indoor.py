str=str(input())
print(str.lower())
